#!/usr/bin/env python

__all__ = ['pe_init', 'elf_init', 'strpatchwork']
